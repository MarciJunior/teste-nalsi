import dotenv from "dotenv";

dotenv.config();

interface AnalysisRequest {
  pairId: string;
  symbol: string;
  price: number;
  changePercent: number;
}

interface AnalysisResponse {
  signal: "BUY" | "SELL" | "HOLD";
  confidence: number;
  reasoning: string;
  technicalIndicators: {
    rsi: string;
    macd: string;
    movingAverages: string;
  };
  entryPoint: number;
  targetPrice: number;
  stopLoss: number;
  riskRewardRatio: number;
}

export async function generateAIAnalysis(
  request: AnalysisRequest
): Promise<AnalysisResponse> {
  console.log(`Generating AI analysis for ${request.symbol}`);

  try {
    // Simulate AI analysis with trading signals based on chart patterns
    const response = await generateAnalysisWithAI(request);
    return response;
  } catch (error) {
    console.error("Error generating analysis:", error);
    return generateFallbackAnalysis(request);
  }
}

async function generateAnalysisWithAI(
  request: AnalysisRequest
): Promise<AnalysisResponse> {
  const apiKey = process.env.OPENAI_API_KEY;

  if (!apiKey) {
    return generateFallbackAnalysis(request);
  }

  const prompt = `You are a professional forex trader analyzing the ${request.symbol} currency pair.
Current Price: ${request.price}
Change: ${request.changePercent}%

Based on technical analysis, provide a trading signal in JSON format:
{
  "signal": "BUY" or "SELL" or "HOLD",
  "confidence": 0-100,
  "reasoning": "Brief explanation of the signal (max 2 sentences)",
  "technicalIndicators": {
    "rsi": "RSI value and interpretation",
    "macd": "MACD status",
    "movingAverages": "MA trend direction"
  },
  "entryPoint": entry price,
  "targetPrice": target price,
  "stopLoss": stop loss price,
  "riskRewardRatio": ratio as number
}

Provide only the JSON response without additional text.`;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      console.error(
        "OpenAI API error:",
        response.status,
        await response.text()
      );
      return generateFallbackAnalysis(request);
    }

    const data: any = await response.json();
    const content = data.choices[0]?.message?.content;

    if (!content) {
      return generateFallbackAnalysis(request);
    }

    // Extract JSON from response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return generateFallbackAnalysis(request);
    }

    const analysis = JSON.parse(jsonMatch[0]);

    return {
      signal: analysis.signal || "HOLD",
      confidence: Math.min(100, Math.max(0, analysis.confidence || 50)),
      reasoning:
        analysis.reasoning ||
        "Unable to determine clear trading signal at this moment.",
      technicalIndicators: {
        rsi:
          analysis.technicalIndicators?.rsi ||
          "RSI not available in AI response",
        macd:
          analysis.technicalIndicators?.macd ||
          "MACD not available in AI response",
        movingAverages:
          analysis.technicalIndicators?.movingAverages ||
          "Moving Averages not available in AI response",
      },
      entryPoint: Number(analysis.entryPoint) || request.price,
      targetPrice:
        Number(analysis.targetPrice) ||
        request.price * (1 + request.changePercent / 100),
      stopLoss: Number(analysis.stopLoss) || request.price * 0.995,
      riskRewardRatio: Number(analysis.riskRewardRatio) || 1.5,
    };
  } catch (error) {
    console.error("Error calling OpenAI API:", error);
    return generateFallbackAnalysis(request);
  }
}

function generateFallbackAnalysis(request: AnalysisRequest): AnalysisResponse {
  // Deterministic analysis based on price movement
  const isUptrend = request.changePercent > 0.2;
  const isMildUp = request.changePercent > 0;

  const signals: { signal: "BUY" | "SELL" | "HOLD"; confidence: number } =
    isUptrend
      ? { signal: "BUY", confidence: 72 }
      : request.changePercent < -0.2
        ? { signal: "SELL", confidence: 68 }
        : { signal: "HOLD", confidence: 55 };

  const priceDelta = request.price * 0.002;

  return {
    signal: signals.signal,
    confidence: signals.confidence,
    reasoning:
      signals.signal === "BUY"
        ? `The ${request.symbol} pair shows strong bullish momentum with positive price action. Technical indicators align with uptrend continuation.`
        : signals.signal === "SELL"
          ? `The ${request.symbol} pair exhibits bearish signals with negative momentum. Risk/reward favors short positions.`
          : `The ${request.symbol} pair is consolidating. Wait for clearer signals before entering a position.`,
    technicalIndicators: {
      rsi: isUptrend ? "RSI 65-70 (Overbought)" : "RSI 35-40 (Oversold)",
      macd: isMildUp ? "MACD above signal line (Bullish)" : "MACD below signal line (Bearish)",
      movingAverages: isUptrend
        ? "Price above 50/200 MA (Uptrend)"
        : "Price below moving averages (Downtrend)",
    },
    entryPoint: request.price,
    targetPrice:
      signals.signal === "BUY"
        ? request.price + priceDelta * 2
        : request.price - priceDelta * 2,
    stopLoss:
      signals.signal === "BUY"
        ? request.price - priceDelta
        : request.price + priceDelta,
    riskRewardRatio:
      signals.signal === "HOLD" ? 1 : signals.confidence > 70 ? 2.5 : 1.8,
  };
}
