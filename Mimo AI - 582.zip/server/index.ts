import express from "express";
import dotenv from "dotenv";
import { setupStaticServing } from "./static-serve.js";
import { generateAIAnalysis } from "./ai.js";
import { getPairData } from "./pairs.js";

dotenv.config();

const app = express();

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API endpoints
app.get("/api/pairs", (req: express.Request, res: express.Response) => {
  try {
    const pairs = getPairData();
    console.log(`Fetched ${pairs.length} forex pairs`);
    res.json(pairs);
  } catch (error) {
    console.error("Error fetching pairs:", error);
    res.status(500).json({ error: "Failed to fetch pairs" });
  }
  return;
});

app.post("/api/analyze", async (req: express.Request, res: express.Response) => {
  try {
    const { pairId, symbol, price, changePercent } = req.body;
    console.log(`Analyzing ${symbol} (${pairId}) at price ${price}`);

    const analysis = await generateAIAnalysis({
      pairId,
      symbol,
      price,
      changePercent,
    });

    console.log(`Analysis complete for ${symbol}: Signal=${analysis.signal}, Confidence=${analysis.confidence}%`);
    res.json({ analysis });
  } catch (error) {
    console.error("Error generating analysis:", error);
    res.status(500).json({ error: "Failed to generate analysis" });
  }
  return;
});

// Export a function to start the server
export async function startServer(port: string | number) {
  try {
    if (process.env.NODE_ENV === "production") {
      setupStaticServing(app);
    }
    app.listen(port, () => {
      console.log(`✅ API Server running on port ${port}`);
      console.log(`📊 FX AI Analyzer ready`);
    });
  } catch (err) {
    console.error("Failed to start server:", err);
    process.exit(1);
  }
}

// Start the server directly if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log("🚀 Starting FX AI Analyzer server...");
  startServer(process.env.PORT || 3001);
}
