// Mock forex pairs data with real-time simulation
export function getPairData() {
  const baseTime = Date.now();
  
  const pairs = [
    {
      id: "eurusd",
      symbol: "EURUSD",
      bid: 1.08457,
      ask: 1.08467,
      changePercent: 0.35,
      timestamp: baseTime,
    },
    {
      id: "gbpusd",
      symbol: "GBPUSD",
      bid: 1.27892,
      ask: 1.27902,
      changePercent: -0.12,
      timestamp: baseTime,
    },
    {
      id: "usdjpy",
      symbol: "USDJPY",
      bid: 149.258,
      ask: 149.268,
      changePercent: 0.58,
      timestamp: baseTime,
    },
    {
      id: "audusd",
      symbol: "AUDUSD",
      bid: 0.66254,
      ask: 0.66264,
      changePercent: 0.72,
      timestamp: baseTime,
    },
    {
      id: "usdcad",
      symbol: "USDCAD",
      bid: 1.36842,
      ask: 1.36852,
      changePercent: -0.28,
      timestamp: baseTime,
    },
    {
      id: "nzdusd",
      symbol: "NZDUSD",
      bid: 0.61125,
      ask: 0.61135,
      changePercent: 0.45,
      timestamp: baseTime,
    },
  ];

  return pairs.map((pair) => ({
    ...pair,
    bid: pair.bid + (Math.random() - 0.5) * 0.0001,
    ask: pair.ask + (Math.random() - 0.5) * 0.0001,
    changePercent: pair.changePercent + (Math.random() - 0.5) * 0.1,
  }));
}
