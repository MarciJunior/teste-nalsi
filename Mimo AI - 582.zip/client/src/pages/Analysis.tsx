import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { ArrowLeft, Loader, AlertCircle, Zap, TrendingUp, TrendingDown } from "lucide-react";
import ChartComponent from "../components/ChartComponent";
import AIAnalysis from "../components/AIAnalysis";

export default function Analysis() {
  const { pair } = useParams<{ pair: string }>();
  const navigate = useNavigate();
  const [pairData, setPairData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/api/pairs");
        const pairs = await response.json();
        const found = pairs.find((p: any) => p.symbol === pair);
        setPairData(found);
        
        if (found) {
          analyzeChart(found);
        }
      } catch (err) {
        setError("Failed to fetch pair data");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    if (pair) {
      fetchData();
    }
  }, [pair]);

  const analyzeChart = async (data: any) => {
    setAnalyzing(true);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          pairId: data.id,
          symbol: data.symbol,
          price: (data.bid + data.ask) / 2,
          changePercent: data.changePercent,
        }),
      });

      if (!response.ok) throw new Error("Analysis failed");
      
      const result = await response.json();
      setAnalysis(result.analysis);
    } catch (err) {
      setError("Failed to analyze chart");
      console.error(err);
    } finally {
      setAnalyzing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="inline-flex p-4 bg-gradient-to-br from-orange-400/20 to-orange-600/20 rounded-2xl mb-4">
            <Loader className="w-12 h-12 text-orange-400 animate-spin" />
          </div>
          <p className="text-orange-400 font-semibold">Loading chart data...</p>
        </div>
      </div>
    );
  }

  if (error || !pairData) {
    return (
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-orange-400 hover:text-orange-300 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Dashboard
        </button>
        
        <div className="rounded-2xl bg-red-500/10 border border-red-500/50 p-8 text-center">
          <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <p className="text-red-400 font-semibold">{error || "Pair not found"}</p>
        </div>
      </main>
    );
  }

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <button
        onClick={() => navigate("/")}
        className="flex items-center gap-2 text-orange-400 hover:text-orange-300 mb-6 transition-colors group"
      >
        <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
        Back to Dashboard
      </button>

      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-4xl font-bold text-white mb-2">{pair}</h2>
            <p className="text-orange-400/70">
              Real-time analysis with AI-powered trading signals
            </p>
          </div>
          <div className="text-right">
            <div className="text-4xl font-mono font-bold text-white">
              {((pairData.bid + pairData.ask) / 2).toFixed(5)}
            </div>
            <div
              className={`flex items-center justify-end gap-2 mt-2 ${
                pairData.changePercent >= 0
                  ? "text-green-400"
                  : "text-red-400"
              }`}
            >
              {pairData.changePercent >= 0 ? (
                <TrendingUp className="w-5 h-5" />
              ) : (
                <TrendingDown className="w-5 h-5" />
              )}
              <span className="text-xl font-semibold">
                {pairData.changePercent >= 0 ? "+" : ""}
                {pairData.changePercent.toFixed(2)}%
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ChartComponent pair={pair} pairData={pairData} />
        </div>

        <div className="lg:col-span-1">
          {analyzing ? (
            <div className="rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-orange-400/30 p-8 flex flex-col items-center justify-center min-h-96">
              <div className="inline-flex p-4 bg-gradient-to-br from-orange-400/20 to-orange-600/20 rounded-2xl mb-4">
                <Loader className="w-8 h-8 text-orange-400 animate-spin" />
              </div>
              <p className="text-orange-400 font-semibold">
                Analyzing chart patterns...
              </p>
            </div>
          ) : analysis ? (
            <AIAnalysis analysis={analysis} pair={pair} />
          ) : null}
        </div>
      </div>
    </main>
  );
}
