import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Loader, RefreshCw, Zap } from "lucide-react";
import PairCard from "../components/PairCard";

interface Pair {
  id: string;
  symbol: string;
  bid: number;
  ask: number;
  changePercent: number;
  timestamp: number;
}

export default function Dashboard() {
  const [pairs, setPairs] = useState<Pair[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const navigate = useNavigate();

  const fetchPairs = async () => {
    try {
      const response = await fetch("/api/pairs");
      const data = await response.json();
      setPairs(data);
    } catch (error) {
      console.error("Error fetching pairs:", error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchPairs();
    const interval = setInterval(fetchPairs, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchPairs();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="inline-flex p-4 bg-gradient-to-br from-orange-400/20 to-orange-600/20 rounded-2xl mb-4">
            <Loader className="w-12 h-12 text-orange-400 animate-spin" />
          </div>
          <p className="text-orange-400 font-semibold">Loading forex pairs...</p>
        </div>
      </div>
    );
  }

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-4xl font-bold text-white mb-2">
              Forex Market Monitor
            </h2>
            <p className="text-orange-400/70">
              Real-time currency pair analysis powered by AI
            </p>
          </div>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-400 to-orange-600 text-white rounded-xl font-semibold hover:shadow-lg hover:shadow-orange-500/50 transition-all duration-300 disabled:opacity-50"
          >
            <RefreshCw
              className={`w-5 h-5 ${refreshing ? "animate-spin" : ""}`}
            />
            Refresh
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pairs.map((pair) => (
            <div
              key={pair.id}
              onClick={() => navigate(`/analysis/${pair.symbol}`)}
              className="cursor-pointer"
            >
              <PairCard pair={pair} />
            </div>
          ))}
        </div>

        {pairs.length === 0 && (
          <div className="text-center py-12">
            <Zap className="w-16 h-16 text-orange-400/40 mx-auto mb-4" />
            <p className="text-gray-400">No forex pairs available</p>
          </div>
        )}
      </div>
    </main>
  );
}
