import { Star } from "lucide-react";

export default function FavoritesList() {
  return (
    <div className="rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-orange-400/30 p-6">
      <div className="flex items-center gap-3 mb-4">
        <Star className="w-5 h-5 text-orange-400 fill-orange-400" />
        <h3 className="text-lg font-bold text-white">Favorites</h3>
      </div>
      <p className="text-gray-400 text-sm">No favorite pairs yet</p>
    </div>
  );
}
