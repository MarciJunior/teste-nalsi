import { TrendingUp, TrendingDown } from "lucide-react";

interface Pair {
  id: string;
  symbol: string;
  bid?: number;
  ask?: number;
  changePercent?: number;
}

interface Props {
  pair: Pair;
}

export default function PairCard({ pair }: Props) {
  if (!pair || pair.bid === undefined || pair.ask === undefined || pair.changePercent === undefined) {
    return null;
  }
  
  const isPositive = pair.changePercent >= 0;

  return (
    <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-orange-400/30 hover:border-orange-400/70 p-6 transition-all duration-300 hover:shadow-xl hover:shadow-orange-500/20 hover:-translate-y-1">
      {/* Animated background effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-orange-400/0 via-orange-400/5 to-orange-400/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-2xl font-bold text-white">{pair.symbol}</h3>
            <p className="text-sm text-orange-400/70">Currency Pair</p>
          </div>
          <div className="p-2 bg-gradient-to-br from-orange-400/20 to-orange-600/20 rounded-xl">
            <TrendingUp className="w-5 h-5 text-orange-400" />
          </div>
        </div>

        {/* Prices */}
        <div className="bg-slate-950/50 rounded-xl p-4 mb-4 border border-orange-400/10">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-gray-400 mb-1">Bid</p>
              <p className="text-lg font-mono font-semibold text-white">
                {pair.bid.toFixed(5)}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-400 mb-1">Ask</p>
              <p className="text-lg font-mono font-semibold text-white">
                {pair.ask.toFixed(5)}
              </p>
            </div>
          </div>
        </div>

        {/* Change percentage */}
        <div
          className={`flex items-center gap-2 px-3 py-2 rounded-lg ${
            isPositive
              ? "bg-green-500/20 text-green-400"
              : "bg-red-500/20 text-red-400"
          }`}
        >
          {isPositive ? (
            <TrendingUp className="w-4 h-4" />
          ) : (
            <TrendingDown className="w-4 h-4" />
          )}
          <span className="font-semibold">
            {isPositive ? "+" : ""}
            {pair.changePercent.toFixed(2)}%
          </span>
        </div>
      </div>
    </div>
  );
}
