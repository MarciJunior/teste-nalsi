import { Link } from "react-router-dom";
import { TrendingUp } from "lucide-react";

export default function Navigation() {
  return (
    <nav className="sticky top-0 z-50 backdrop-blur-lg bg-slate-950/80 border-b border-orange-400/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <Link
          to="/"
          className="flex items-center gap-3 hover:opacity-80 transition-opacity"
        >
          <div className="p-2 bg-gradient-to-br from-orange-400 to-orange-600 rounded-xl">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-400 to-orange-600 bg-clip-text text-transparent">
              FX AI Analyzer
            </h1>
            <p className="text-xs text-orange-400/70">Real-time Forex Analysis</p>
          </div>
        </Link>
      </div>
    </nav>
  );
}
