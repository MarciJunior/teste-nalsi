import { useEffect, useRef } from "react";
import { TrendingUp } from "lucide-react";

interface Props {
  pair: string | undefined;
  pairData: any;
}

export default function ChartComponent({ pair, pairData }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current || !pair) return;

    // Create TradingView widget script
    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/tv.js";
    script.async = true;

    script.onload = () => {
      if (window.TradingView) {
        const tvLanguage = "en";
        
        // Clear previous widget
        if (containerRef.current) {
          containerRef.current.innerHTML = "";
        }

        new window.TradingView.widget({
          autosize: true,
          symbol: `FX_IDC:${pair}`,
          interval: "60",
          timezone: "Etc/UTC",
          theme: "dark",
          style: "1",
          locale: tvLanguage,
          toolbar_bg: "#1f2937",
          enable_publishing: false,
          withdateranges: true,
          hide_side_toolbar: false,
          allow_symbol_change: false,
          details: true,
          hotlist: false,
          studies: ["STD;RSI", "STD;MACD"],
          container_id: "tradingview_chart",
          custom_css_url: "/tradingview-custom.css",
        });
      }
    };

    if (document.body.contains(script)) {
      document.body.removeChild(script);
    }
    document.body.appendChild(script);

    return () => {
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, [pair]);

  return (
    <div className="rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-orange-400/30 p-6 overflow-hidden">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-gradient-to-br from-orange-400 to-orange-600 rounded-xl">
          <TrendingUp className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">Chart Analysis</h3>
          <p className="text-sm text-orange-400/70">1H timeframe with Technical Indicators</p>
        </div>
      </div>

      <div
        ref={containerRef}
        id="tradingview_chart"
        className="h-96 rounded-xl overflow-hidden bg-slate-950"
      />
    </div>
  );
}

declare global {
  interface Window {
    TradingView: any;
  }
}
