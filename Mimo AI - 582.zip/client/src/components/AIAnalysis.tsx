import { TrendingUp, TrendingDown, Zap, Target, AlertCircle } from "lucide-react";

interface Props {
  analysis: {
    signal: "BUY" | "SELL" | "HOLD";
    confidence: number;
    reasoning: string;
    technicalIndicators: {
      rsi: string;
      macd: string;
      movingAverages: string;
    };
    entryPoint: number;
    targetPrice: number;
    stopLoss: number;
    riskRewardRatio: number;
  };
  pair: string | undefined;
}

export default function AIAnalysis({ analysis, pair }: Props) {
  const signalColor =
    analysis.signal === "BUY"
      ? "from-green-500/20 to-green-600/20 border-green-500/50"
      : analysis.signal === "SELL"
        ? "from-red-500/20 to-red-600/20 border-red-500/50"
        : "from-yellow-500/20 to-yellow-600/20 border-yellow-500/50";

  const signalTextColor =
    analysis.signal === "BUY"
      ? "text-green-400"
      : analysis.signal === "SELL"
        ? "text-red-400"
        : "text-yellow-400";

  const signalIcon =
    analysis.signal === "BUY" ? (
      <TrendingUp className="w-8 h-8" />
    ) : analysis.signal === "SELL" ? (
      <TrendingDown className="w-8 h-8" />
    ) : (
      <Zap className="w-8 h-8" />
    );

  return (
    <div className="rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-orange-400/30 p-6 sticky top-24">
      {/* Signal Card */}
      <div
        className={`rounded-xl bg-gradient-to-br ${signalColor} border p-6 mb-6`}
      >
        <div className="flex items-center gap-4 mb-4">
          <div className={signalTextColor}>{signalIcon}</div>
          <div>
            <p className="text-xs text-gray-400 uppercase tracking-wide">
              AI Signal
            </p>
            <h3 className={`text-3xl font-bold ${signalTextColor}`}>
              {analysis.signal}
            </h3>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-300">Confidence</span>
          <div className="flex items-center gap-2">
            <div className="w-32 h-2 bg-slate-700 rounded-full overflow-hidden">
              <div
                className={`h-full ${
                  analysis.confidence >= 70
                    ? "bg-green-500"
                    : analysis.confidence >= 50
                      ? "bg-yellow-500"
                      : "bg-red-500"
                }`}
                style={{ width: `${analysis.confidence}%` }}
              />
            </div>
            <span className="text-sm font-semibold text-white min-w-fit">
              {analysis.confidence}%
            </span>
          </div>
        </div>
      </div>

      {/* Reasoning */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-3">
          <AlertCircle className="w-4 h-4 text-orange-400" />
          <h4 className="font-semibold text-white text-sm">Analysis</h4>
        </div>
        <p className="text-sm text-gray-300 leading-relaxed bg-slate-950/50 rounded-lg p-3 border border-orange-400/10">
          {analysis.reasoning}
        </p>
      </div>

      {/* Price Targets */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-950/50 rounded-lg p-4 border border-green-500/20">
          <p className="text-xs text-gray-400 mb-1 uppercase tracking-wide">
            Entry Point
          </p>
          <p className="text-lg font-mono font-bold text-green-400">
            {analysis.entryPoint.toFixed(5)}
          </p>
        </div>
        <div className="bg-slate-950/50 rounded-lg p-4 border border-red-500/20">
          <p className="text-xs text-gray-400 mb-1 uppercase tracking-wide">
            Stop Loss
          </p>
          <p className="text-lg font-mono font-bold text-red-400">
            {analysis.stopLoss.toFixed(5)}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-950/50 rounded-lg p-4 border border-blue-500/20">
          <p className="text-xs text-gray-400 mb-1 uppercase tracking-wide">
            Target Price
          </p>
          <p className="text-lg font-mono font-bold text-blue-400">
            {analysis.targetPrice.toFixed(5)}
          </p>
        </div>
        <div className="bg-slate-950/50 rounded-lg p-4 border border-purple-500/20">
          <p className="text-xs text-gray-400 mb-1 uppercase tracking-wide">
            Risk/Reward
          </p>
          <p className="text-lg font-mono font-bold text-purple-400">
            1:{analysis.riskRewardRatio.toFixed(2)}
          </p>
        </div>
      </div>

      {/* Technical Indicators */}
      <div className="bg-slate-950/50 rounded-lg p-4 border border-orange-400/20">
        <h4 className="font-semibold text-white text-sm mb-3 flex items-center gap-2">
          <Target className="w-4 h-4 text-orange-400" />
          Technical Indicators
        </h4>
        <div className="space-y-2 text-sm">
          <div>
            <span className="text-gray-400">RSI:</span>
            <span className="ml-2 text-orange-400 font-mono">
              {analysis.technicalIndicators.rsi}
            </span>
          </div>
          <div>
            <span className="text-gray-400">MACD:</span>
            <span className="ml-2 text-orange-400 font-mono">
              {analysis.technicalIndicators.macd}
            </span>
          </div>
          <div>
            <span className="text-gray-400">Moving Averages:</span>
            <span className="ml-2 text-orange-400 font-mono">
              {analysis.technicalIndicators.movingAverages}
            </span>
          </div>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="mt-6 pt-4 border-t border-orange-400/20">
        <p className="text-xs text-gray-500 leading-relaxed">
          ⚠️ This analysis is AI-generated for educational purposes only. Always
          do your own research and manage risk accordingly.
        </p>
      </div>
    </div>
  );
}
